# artifact report

- file: `C:\Users\whisky\Downloads\New folder\Razmut\razmut_agent.dll`
- size: 3196416 bytes (3.0 MiB)
- format: PE32+, x86-64
- image base: 0x180000000
- entry rva: 0x8e038
- crc32: 0xfc67602c

## sections

| name | rva | virtual | raw | x |
| --- | --- | --- | --- | --- |
| .text | 0x1000 | 696982 | 697344 | yes |
| .rdata | 0xac000 | 2447884 | 2448384 |  |
| .data | 0x302000 | 27464 | 11264 |  |
| .pdata | 0x309000 | 27420 | 27648 |  |
| .gfids | 0x310000 | 140 | 512 |  |
| .tls | 0x311000 | 33 | 512 |  |
| _RDATA | 0x312000 | 500 | 512 |  |
| .reloc | 0x313000 | 9004 | 9216 |  |

## imports

- CRYPT32.dll: 1 functions
- OLEAUT32.dll: 2 functions
- bcryptprimitives.dll: 1 functions
- kernel32.dll: 147 functions
- ntdll.dll: 3 functions
- api-ms-win-core-synch-l1-2-0.dll: 3 functions
- USER32.dll: 2 functions
- WS2_32.dll: 4 functions

## exports

- `razmut_build_profile` at 0xfde6
- `razmut_entry` at 0xfdec
